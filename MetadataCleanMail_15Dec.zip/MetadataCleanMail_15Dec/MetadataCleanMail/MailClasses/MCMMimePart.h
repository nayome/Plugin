//
//  MCMMimePart.h
//  MetadataCleanMail
//
//  Created by Nayome Devapriya on 15/12/17.
//  Copyright © 2017 Test. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MimePart.h"
@class MimeBody;

@class MFMimeDecodeContext, _NSDataMessageStoreMessage;

@interface MCMMimePart : NSObject
- (BOOL)MCM_usesKnownSignatureProtocol;
- (id)MCM_decodeWithContext:(id)ctx;
- (id)MCM_decodeTextPlainWithContext:(MFMimeDecodeContext *)ctx;
- (id)MCM_decodeTextHtmlWithContext:(MFMimeDecodeContext *)ctx;
- (id)MCM_decodeApplicationOctet_streamWithContext:(MFMimeDecodeContext *)ctx;
- (void)MCM_verifySignature;
- (BOOL)MCM_isEncrypted;
- (BOOL)MCM_isMimeEncrypted;
- (BOOL)MCM_isSigned;
- (BOOL)MCM_IsMimeSigned;
- (id)MCM_newEncryptedPartWithData:(NSData *)data recipients:(id)recipients encryptedData:(NSData **)encryptedData NS_RETURNS_RETAINED;
- (id)MCM_newSignedPartWithData:(id)data sender:(id)sender signatureData:(id *)signatureData NS_RETURNS_RETAINED;
- (void)MCM_clearCachedDecryptedMessageBody;

@end

@interface MCMMimePart (MailMethods)
- (MimeBody *)mimeBody;
- (MimePart *)startPart;
- (MimePart *)parentPart;
- (MimePart *)nextSiblingPart;
- (NSData *)bodyData;
- (id)dispositionParameterForKey:(NSString *)key;
- (BOOL)isType:(NSString *)type subtype:(NSString *)subtype;
- (id)bodyParameterForKey:(NSString *)key;
- (NSArray *)subparts;
- (id)decryptedMessageBody;
- (void)setDispositionParameter:(id)parameter forKey:(id)key;
- (BOOL)isAttachment;
- (NSData *)signedData;
- (NSString *)type;
- (NSString *)subtype;
- (id)contentTransferEncoding;

@end
