//
//  MCMComposeViewController.m
//  MetadataCleanMail
//
//  Created by Nayome Devapriya on 12/12/17.
//  Copyright © 2017 Test. All rights reserved.
//

#import "MCMComposeViewController.h"
#import "MCMProcessingAlert.h"
#import "MCMMailMessage.h"
#import "ComposeBackEnd.h"
#import "MCMMailDocumentEditor.h"
#import "ComposeViewController.h"
#import "AttachmentViewController.h"
#import "MCAttachment.h"

@interface MCMComposeViewController (MCMNoImplementation)
//- (void)send:(id)arg1;
@end

@implementation MCMComposeViewController

 - (void)MCM_send:(id)arg1 {
    if ([[[NSUserDefaults standardUserDefaults] objectForKey:@"MCMCleanON"] integerValue] == NSOnState) {
        
        ComposeBackEnd *backEnd = ((ComposeViewController *)self).backEnd;
        NSLog(@"@@@@@@@@@@@@@@ here are the new attachments %@",backEnd.attachments);
        
        MCMProcessingAlert *alert = [[MCMProcessingAlert alloc] init];
        dispatch_async(dispatch_get_main_queue(), ^{
            [alert startProcessing:backEnd.attachments];
        });
        [NSApp runModalForWindow:[alert window]];
    }
    
    [self MCM_send:arg1];
}

//- (void)MCM_sendMessageAfterChecking:(id)arg1 {
//    if ([[[NSUserDefaults standardUserDefaults] objectForKey:@"MCMCleanON"] integerValue] == NSOnState) {
//
//        ComposeBackEnd *backEnd = ((ComposeViewController *)self).backEnd;
//        NSLog(@"@@@@@@@@@@@@@@ here are the new attachments %@",backEnd.attachments);
//
//        for (AttachmentViewController *attachVC in backEnd.attachments) {
//            NSLog(@" file name is %@",attachVC.attachment.remoteURL);
//
//        }
////        MCMProcessingAlert *alert = [[MCMProcessingAlert alloc] init];
////        alert.fileName = @"TESt 1";
////        [NSApp runModalForWindow:[alert window]];
//    }
//
//    [self MCM_sendMessageAfterChecking:arg1];
//}
//
@end
