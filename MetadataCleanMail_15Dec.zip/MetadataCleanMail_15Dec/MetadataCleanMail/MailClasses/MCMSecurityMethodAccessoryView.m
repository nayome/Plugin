//
//  MCMSecurityMethodAccessoryView.m
//  MetadataCleanMail
//
//  Created by DATAPPS on 12/10/17.
//  Copyright © 2017 Test. All rights reserved.
//

#import "MCMSecurityMethodAccessoryView.h"
#import "NSBezierPath+StrokeExtensions.h"
#import "NSBezierPath_KBAdditions.h"
#import "NSWindow+MetadataCleanMail.h"

@interface MCMSecurityMethodAccessoryView ()
// cell defined as NSButtonCell to need no casts.
@property NSButtonCell *cell;

@end

@interface GMSecurityMethodAccessoryCell : NSButtonCell
@end
@implementation GMSecurityMethodAccessoryCell

@end


@implementation MCMSecurityMethodAccessoryView
@synthesize  active = _active,  style = _style;
@dynamic cell;

+ (Class)cellClass {
    return [GMSecurityMethodAccessoryCell class];
}

- (id)init {
    return [self initWithStyle:MCMSecurityMethodAccessoryViewStyleToolbarItem];
}

- (id)initWithStyle:(MCMSecurityMethodAccessoryViewStyle)style {
    self = [super initWithFrame:NSMakeRect(0.0f, 0.0f, GMSMA_DEFAULT_WIDTH, GMSMA_DEFAULT_HEIGHT)];
    if (!self) {
        return nil;
    }
    [[self cell] setTitle:@"MetaClean ON"];
    [self setButtonType:NSButtonTypeSwitch]; //Set what type button You want
    
    if ([[NSUserDefaults standardUserDefaults] objectForKey:@"MCMCleanON"] != nil)
    {
        self.state = [[[NSUserDefaults standardUserDefaults] objectForKey:@"MCMCleanON"] integerValue];
    }
    else {
        self.state = NSOffState;
    }
    self.autoresizingMask = NSViewMinYMargin | NSViewMinXMargin;
    _style = style;
    return self;
}

- (BOOL)isFlipped {
    return NO;
}
- (void)setActive:(BOOL)active {
    _active = active;
    self.needsDisplay = YES;
}

@end
