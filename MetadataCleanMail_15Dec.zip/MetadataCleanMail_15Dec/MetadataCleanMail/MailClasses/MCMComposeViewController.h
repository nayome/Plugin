//
//  MCMComposeViewController.h
//  MetadataCleanMail
//
//  Created by Nayome Devapriya on 12/12/17.
//  Copyright © 2017 Test. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MCMComposeViewController : NSObject
- (void)MCM_send:(id)arg1;
//- (void)MCM_sendMessageAfterChecking:(id)arg1;
@end
