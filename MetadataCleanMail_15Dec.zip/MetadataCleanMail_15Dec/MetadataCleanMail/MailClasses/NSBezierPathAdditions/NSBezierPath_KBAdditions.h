//
//  NSBezierPath_KBAdditions.h
//  MetadataCleanMail
//
//  Created by DATAPPS on 12/10/17.
//  Copyright © 2017 Test. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Cocoa/Cocoa.h>

typedef enum KBCornerTypes
{
    KBTopLeftCorner = 1,
    KBTopRightCorner = 2,
    KBBottomLeftCorner = 4,
    KBBottomRightCorner = 8
} KBCornerType;

@interface NSBezierPath (KBAdditions)
+ (NSBezierPath *)bezierPathWithRoundedRect:(NSRect)aRect cornerRadius:(float)radius;
+ (NSBezierPath *)bezierPathWithRoundedRect:(NSRect)aRect
                                  inCorners:(KBCornerType)corners
                               cornerRadius:(float)radius
                                    flipped:(BOOL)isFlipped;
@end
