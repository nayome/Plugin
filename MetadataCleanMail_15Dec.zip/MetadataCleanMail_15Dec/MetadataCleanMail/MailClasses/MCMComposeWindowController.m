//
//  MCMComposeWindowController.m
//  MetadataCleanMail
//
//  Created by DATAPPS on 12/10/17.
//  Copyright © 2017 Test. All rights reserved.
//

#import "MCMComposeWindowController.h"
#import <objc/runtime.h>
#import "MCMSecurityMethodAccessoryView.h"
#import "MCMProcessingAlert.h"

@interface MCMComposeWindowController (MCMNoImplementation)
- (void)_performSendAnimation;
- (void)cancelSendAnimation;
@end

@implementation MCMComposeWindowController

- (void)setIvar:(id)key value:(id)value {
    [self setIvar:key value:value assign:NO];
}

- (void)setIvar:(id)key value:(id)value assign:(BOOL)shouldAssign {
    if(shouldAssign)
        objc_setAssociatedObject(self, (__bridge const void *)(key), value, OBJC_ASSOCIATION_ASSIGN);
    else
        objc_setAssociatedObject(self, (__bridge const void *)(key), value, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (id)getIvar:(id)key {
    return objc_getAssociatedObject(self, (__bridge const void *)(key));
}

- (void)removeIvar:(id)key {
    [self setIvar:key value:nil];
}


- (void)MCM_performSendAnimation {
    NSLog(@"###### statred perform send animation");
    // Store the the current frame position, to restore it in case of an error.
    NSPoint currentOrigin = [(id)self window].frame.origin;
    [self setIvar:@"WindowFrameOriginBeforeAnimation" value:@{@"X": @(currentOrigin.x), @"Y": @(currentOrigin.y)}];
    [self MCM_performSendAnimation];
    return;
}

- (void)restorePositionBeforeAnimation {
    NSDictionary *originBeforeAnimation = [self getIvar:@"WindowFrameOriginBeforeAnimation"];
    if(!originBeforeAnimation)
        return;

    [self removeIvar:@"WindowFrameOriginBeforeAnimation"];
    [[(id)self window] setFrameOrigin:NSMakePoint([originBeforeAnimation[@"X"] floatValue], [originBeforeAnimation[@"Y"] floatValue])];
    [[(id)self window] makeKeyAndOrderFront:0];
    return;
}

- (id)MCM_toolbarDefaultItemIdentifiers:(id)toolbar {
    NSLog(@"######## in MCM_toolbarDefaultItemIdentifiers");
    id defaultItemIdentifiers = [self MCM_toolbarDefaultItemIdentifiers:toolbar];
    
    // Appending the security method identifier to toggle between OpenPGP and S/MIME.
    NSMutableArray *identifiers = [defaultItemIdentifiers mutableCopy];
    [identifiers addObject:@"toggleMetadataCleanMailState:"];
    NSLog(@"####### identifiers are %@",identifiers);
    return identifiers;
}

- (id)MCM_toolbar:(id)toolbar itemForItemIdentifier:(id)itemIdentifier willBeInsertedIntoToolbar:(BOOL)willBeInsertedIntoToolbar {
    NSLog(@"######## in MCM_toolbar");

    if(![itemIdentifier isEqualToString:@"toggleMetadataCleanMailState:"]) {
        return [self MCM_toolbar:toolbar itemForItemIdentifier:itemIdentifier willBeInsertedIntoToolbar:willBeInsertedIntoToolbar];
    }
    
    // Make sure our toolbar item was not already added.
    for(NSToolbarItem *item in [toolbar items]) {
        if([item.itemIdentifier isEqualToString:itemIdentifier])
            return nil;
    }
    
    // The delegate of GMSecurityMethodAccessoryView will be the current composeViewController.
    // At this point it's however not yet set on the ComposeWindowController, so once the
    // compose view controller is ready, it will set if self up as delegate.
    MCMSecurityMethodAccessoryView *securityMethodAccessoryView = [[MCMSecurityMethodAccessoryView alloc] initWithStyle:MCMSecurityMethodAccessoryViewStyleToolbarItem];
    [self setIvar:@"SecurityMethodAccessoryView" value:securityMethodAccessoryView];
    
    NSToolbarItem *item = [[NSToolbarItem alloc] initWithItemIdentifier:itemIdentifier];
    [item setView:securityMethodAccessoryView];
    [item setTarget:self];
    [item setAction:@selector(toggleButtonState:)];
    return item;
}

-(void)toggleButtonState:(id)sender {
    [[NSUserDefaults standardUserDefaults] setObject:[NSNumber numberWithInteger:[sender state]] forKey:@"MCMCleanON"];
    
//    NSLog(@"######## button clicked");
//    if ([sender state] == NSOnState) {
//        MCMProcessingAlert *alert = [[MCMProcessingAlert alloc] init];
//        [NSApp runModalForWindow:[alert window]];
//    }

}

@end
