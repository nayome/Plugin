//
//  MCMQuotedMailOriginal.m
//  MetadataCleanMail
//
//  Created by DATAPPS on 12/9/17.
//  Copyright © 2017 Test. All rights reserved.
//

#import <WebKit/DOMHTMLBRElement.h>
#import <WebKit/DOMDocumentFragment.h>
#import <WebKit/DOMHTMLDivElement.h>
#import <WebKit/DOMHTMLDocument.h>
#import <WebKit/DOMHTMLCollection.h>
#import <WebKit/DOMNodeList.h>
#import <WebKit/DOMElement.h>
#import <WebKit/WebArchive.h>
#import "MCMQuotedMailOriginal.h"

@interface MCMQuotedMailOriginal (MCMNoImplementation)
- (id)htmlDocument;
- (DOMDocumentFragment *)createDocumentFragmentWithMarkupString: (NSString *)str;
- (id)descendantsWithClassName:(NSString *)str;
- (DOMDocumentFragment *)createFragmentForWebArchive:(WebArchive *)webArch;
- (BOOL)hasContents;
- (BOOL)containsRichText;
@end

@interface DOMNode ()
@property(readonly) unsigned childElementCount;
@property(copy) NSString *outerHTML;
- (NSString *)stringValue;
@end

NSString *ApplePlainTextBody = @"ApplePlainTextBody";
NSString *AppleOriginalContents = @"AppleOriginalContents";
NSString *AppleMailSignature = @"AppleMailSignature";
NSString *WROTE_TEXT_REGEX_STRING = @":\\s*(\\n|\\r)";
NSString *TAG_BLOCKQUOTE = @"BLOCKQUOTE";

@implementation MCMQuotedMailOriginal

- (void)prepareQuotedPlainText
{
    originalEmail=[[[document htmlDocument]
                    descendantsWithClassName:ApplePlainTextBody] objectAtIndex:0];
    
    NSLog(@" ######Original plain email: %@", originalEmail);
    
    if ( [[originalEmail idName] isEqualToString:AppleMailSignature] )
    {
        int itemNum = 2;
        
        //check that the second child isn't a break element and if so, go to the child 3
        if ( [[[[originalEmail children] item:itemNum] outerHTML] isEqualToString:@"<br>"] )
        {
            itemNum = 3;
        }
        originalEmail = (id)[[originalEmail children] item:itemNum];
    }
}

- (BOOL)isBlockquoteTagPresent
{
    return (![[NSUserDefaults standardUserDefaults] boolForKey: @"SupressQuoteBarsInComposeWindows"]);
}


- (id)initWithMailMessage:(id)mailMessage msgComposeType:(int)composeType
{
    if ( self = [super init] )
    {
        document = [mailMessage document];
        msgComposeType = composeType;
        
        NSLog(@" ######Mail Document: %@", document);
        NSLog(@" ######Composing message type is %d", msgComposeType);
        NSLog(@" ######Complete HTML string %@", [[[document htmlDocument] body] innerHTML]);
        
        //now initialize the other vars
        [self initVars];
        
        //if there is not a child in the original email, it must be plain text
        if ([originalEmail firstChild] == nil || !isHTMLMail)
        {
            //prep the plain text
            [self prepareQuotedPlainText];
        }
        
        //now that the email is set... set the child nodes
        dhc = [originalEmail childNodes];
        
        //identifying blockquote tag
        NSLog(@" ######isBlockquotePresent = %@", [self isBlockquoteTagPresent] ? @"YES" : @"NO");
        
        //now get the quoted content and remove the first part (where it says "On ... X wrote"
        // "... message"
        if (dhc.length >= 1)
        {
            if (isHTMLMail)
                [self removeHTMLHeaderPrefix];
            else
                [self removePlainTextHeaderPrefix];
        }
    }
    
    return self;
}

- (DOMNode *)getBlockquoteTagNode
{
    NSLog(@" ######No of child nodes: %d", dhc.length);
    for (int i=0; i < dhc.length; i++)
    {
        if ([[[dhc item:i] nodeName] isEqualToString:TAG_BLOCKQUOTE])
        {
            NSLog(@" ######getBlockquoteTagNode:: %@ Node found at %d", TAG_BLOCKQUOTE, i);
            return [dhc item:i];
        }
    }
    
    return nil;
}

#pragma mark Class private methods

- (void)initVars
{
//    if ([MetaCleanMailBundle isSierraOrGreater])
//    {
        // OS Sierra improvements, Apple made complicated to detect HTML vs Plain
        // So, first try HTML and fallback to Plain Text email.
        // I feed sad for Plain text mail users.
        if ([[document htmlDocument] descendantsWithClassName:AppleOriginalContents] != NULL
            || [[document htmlDocument] descendantsWithClassName:AppleOriginalContents] != nil)
        {
            isHTMLMail = YES;
            originalEmail=[[[document htmlDocument]
                            descendantsWithClassName:AppleOriginalContents] objectAtIndex:0];
        }
        else
        {
            isHTMLMail = NO;
            originalEmail=[[[document htmlDocument]
                            descendantsWithClassName:ApplePlainTextBody] objectAtIndex:0];
        }
//    }
//    else
//    {
//        // identifying is this plain or html mail compose in reply or reply all;
//        // forward mail is not our compose since it falls
//        // into default setting of compose type in user mail client
//        // AppleOriginalContents: (isHTMLMail=YES) | ApplePlainTextBody: (isHTMLMail=NO)
//        if ([[document htmlDocument] descendantsWithClassName:ApplePlainTextBody] == NULL
//            || [[document htmlDocument] descendantsWithClassName:ApplePlainTextBody] == nil)
//        {
//            isHTMLMail = YES;
//            originalEmail=[[[document htmlDocument]
//                            descendantsWithClassName:AppleOriginalContents] objectAtIndex:0];
//        }
//        else
//        {
//            isHTMLMail = NO;
//            originalEmail=[[[document htmlDocument]
//                            descendantsWithClassName:ApplePlainTextBody] objectAtIndex:0];
//        }
//    }
    
    NSLog(@" ######Composing mail isHTMLMail %@", (isHTMLMail ? @"YES" : @"NO"));
    
    NSString *borderString = (isHTMLMail) ?
    @"<hr style='border:none;border-top:solid #B5C4DF 1.0pt;padding:0 0 0 0;margin:10px 0 5px 0;' />" : (msgComposeType == 3) ? @"---------- Forwarded Message ----------<br />" : @"---------- Original Message ----------<br />";
    
    NSLog(@" ######initVars Header border text: %@", borderString);
    
    // now initialze header border string into html form
    headerBorder = [self createDocumentFragment:borderString];
    
    textNodeLocation = 0;
}

- (void)removePlainTextHeaderPrefix
{
    DOMNodeList *nodeList;
    DOMHTMLElement *emailDocument;
    
    if ([self isBlockquoteTagPresent])
    {
        emailDocument = (DOMHTMLElement *)[self getBlockquoteTagNode];
        nodeList = [emailDocument childNodes];
    }
    else
    {
        nodeList = dhc;
        emailDocument = (DOMHTMLElement *)originalEmail;
    }
    
    for (int i=0; i < nodeList.length; i++)
    {
        DOMNode *node = [nodeList item:i];
        NSLog(@" ######current location %d, nodeType %d, nodeName %@", i, [node nodeType], [node nodeName]);
        
        if ([node nodeType] == 3) // Text node, On ..., Wrote is text
        {
            NSLog(@" ######Text Node found at %d, name is %@", i, [node nodeName]);
            textNodeLocation = i; break;
        }
    }
    
    @try {
        // if signature at top, item==3 else item==1
        [emailDocument removeChild:[nodeList item:textNodeLocation]];
        
        while ([[[nodeList item:textNodeLocation] nodeName] isEqualToString:@"BR"]) {
            [emailDocument removeChild:[nodeList item:textNodeLocation]];
        }
    }
    @catch (NSException *exception) {
        NSLog(@" ######%@",exception.description);
    }
    
    //find the quoted text - if plain text (blockquote does not exist), -which- will point to br element
    for (int i=0; i<[emailDocument childElementCount]; i++)
    {
        if ( [[[[emailDocument childNodes] item:i] nodeName] isEqualToString:TAG_BLOCKQUOTE] ) //this is the quoted text
        {
            textNodeLocation = i; break;
        }
    }
    
    NSLog(@" ######New header location for Plain Text mail is %d", textNodeLocation);
}

- (void)removeHTMLHeaderPrefix
{
    DOMNodeList *nodeList;
    DOMHTMLElement *emailDocument;
    
    if ([self isBlockquoteTagPresent])
    {
        emailDocument = (DOMHTMLElement *)[self getBlockquoteTagNode];
        nodeList = [emailDocument childNodes];
    }
    else
    {
        nodeList = dhc;
        emailDocument = (DOMHTMLElement *)originalEmail;
    }
    
    @try {
            NSLog(@" ######Handling remaining locale by Regex");
            NSError *error = nil;
            NSRegularExpression *regex = [NSRegularExpression
                                          regularExpressionWithPattern:WROTE_TEXT_REGEX_STRING
                                          options:NSRegularExpressionCaseInsensitive
                                          error:&error];
            NSRange textRange = [regex
                                 rangeOfFirstMatchInString:[[emailDocument firstChild] stringValue]
                                 options:0
                                 range:NSMakeRange(0, [[[emailDocument firstChild] stringValue] length])];
            NSLog(@" ######Before while loop, Text range is %@", NSStringFromRange(textRange));
            
            //keep removing items until we find the "wrote:" text...
            while ( textRange.location == NSNotFound )
            {
                [emailDocument removeChild:[emailDocument firstChild]];
                textRange = [regex
                             rangeOfFirstMatchInString:[[emailDocument firstChild] stringValue]
                             options:0
                             range:NSMakeRange(0, [[[emailDocument firstChild] stringValue] length])];
                NSLog(@" ######Text range is %@", NSStringFromRange(textRange));
            }
        
        DOMNode *node = [[emailDocument firstChild] firstChild];
        //remove the line with the "wrote:" text
        if (node)
        {
            NSLog(@" ######Node name: %@, Node Type: %hu, Node Value: %@", [node nodeName], [node nodeType], [node stringValue]);
            [[emailDocument firstChild] removeChild:node];
        }
        
        // remove the first new line element to shorten the distance between the new email and quoted text
        // this is required in order to get the header inside the quoted text line
        while ([[[emailDocument firstChild] nodeName] isEqualToString:@"BR"]) {
            [emailDocument removeChild:[emailDocument firstChild]];
        }
    }
    @catch (NSException *exception) {
        NSLog(@" ######RWH %@", [exception reason]);
    }
}

- (DOMDocumentFragment *)createDocumentFragment:(NSString *)htmlString
{
    return [[document htmlDocument]
            createDocumentFragmentWithMarkupString:htmlString];
}

@end
