//
//  MCMMailDocumentEditor.m
//  MetadataCleanMail
//
//  Created by DATAPPS on 12/10/17.
//  Copyright © 2017 Test. All rights reserved.
//

#import "MCMMailDocumentEditor.h"
#import <objc/runtime.h>
#import "MCMProcessingAlert.h"

//#import "MCMSecurityMethodAccessoryView.h"

static const NSString *kUnencryptedReplyToEncryptedMessage = @"unencryptedReplyToEncryptedMessage";

@implementation MCMMailDocumentEditor

- (void)setIvar:(id)key value:(id)value {
    [self setIvar:key value:value assign:NO];
}

- (void)setIvar:(id)key value:(id)value assign:(BOOL)shouldAssign {
    if(shouldAssign)
        objc_setAssociatedObject(self, (__bridge const void *)(key), value, OBJC_ASSOCIATION_ASSIGN);
    else
        objc_setAssociatedObject(self, (__bridge const void *)(key), value, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (id)getIvar:(id)key {
    return objc_getAssociatedObject(self, (__bridge const void *)(key));
}

- (void)removeIvar:(id)key {
    [self setIvar:key value:nil];
}

- (void)updateSecurityMethodHighlight {
    NSLog(@"######### ha ha ttest");
}


- (void)MADealloc {
    // Sometimes this fails, so simply ignore it.
    @try {
        [(NSNotificationCenter *)[NSNotificationCenter defaultCenter] removeObserver:self];
//        [(MailNotificationCenter *)[NSClassFromString(@"MailNotificationCenter") defaultCenter] removeObserver:self];
    }
    @catch(NSException *e) {
        
    }
    [self MADealloc];
}

- (BOOL)isUnencryptedReplyToEncryptedMessageWithChecklist:(NSMutableArray *)checklist {
    // While Mail.app internally removes objects from the checklist, we instead add one
    // if the user explicitly told us to continue with sending.
    // We have to handle it this way, since sendMessageAfterChecking is called for each failing
    // check and we can't determine which one is the first call, to correctly add our own item to the checklist,
    // and later remove it, when the check has cleared.
    // So instead we add an item.
    
    // If there is no checklist, we have nothing to check.
    // If we would still check, we head an infinite loop.
    NSLog(@"###### isUnencryptedReplyToEncryptedMessageWithChecklist");
    if (!checklist) {
        return NO;
    }
    
    
//    ComposeBackEnd *backEnd = (ComposeBackEnd *)[(MailDocumentEditor *)self backEnd];
//    NSDictionary *securityProperties = [(MCMMailMessage *)backEnd securityProperties];
//
//    BOOL isReply = [(MCMMailMessage *)backEnd messageIsBeingReplied];
//    BOOL originalMessageIsEncrypted = ((Message_GPGMail *)[backEnd originalMessage]).PGPEncrypted;
//    BOOL replyShouldBeEncrypted = [(MCMMailMessage *)[(MailDocumentEditor *)self backEnd] GMEncryptIfPossible] && [securityProperties[@"shouldEncrypt"] boolValue];
//
//    // If checklist contains the unencryptedReplyToEncryptedMessage item, it means
//    // that the user decided to send the message regardless of our warning.
//    if(isReply && originalMessageIsEncrypted && !replyShouldBeEncrypted && ![checklist containsObject:kUnencryptedReplyToEncryptedMessage]) {
//        // Warn the user.
//        return YES;
//    }
    
    // Isn't a un-encrypted reply to an encrypted message or
    // the user decided to send the message regardless of our warning
    return NO;
}


- (void)MCM_SendMessageAfterChecking:(NSMutableArray *)checklist {
    NSLog(@"####### MCM_SendMessageAfterChecking");
//    // If this is an unencrypted reply to an encrypted message, display a warning
//    // to the user and simply return. The message won't be sent until the checklist is cleared.
//    // Otherwise call sendMessageAfterChecking so that Mail.app can perform its internal checks.
//    if([self isUnencryptedReplyToEncryptedMessageWithChecklist:checklist]) {
////        [self displayWarningForUnencryptedReplyToEncryptedMessageUpdatingChecklist:checklist];
//        return;
//    }
//   MCMProcessingAlert *alert = [[MCMProcessingAlert alloc] init];
//            alert.fileName = @"TESt 1";
//            [NSApp runModalForWindow:[alert window]];
    [self MCM_SendMessageAfterChecking:checklist];
}

- (void)MASetDelegate:(id)delegate {
    [self MASetDelegate:delegate];
    // Store the delegate as associated object, otherwise Mail.app releases it to soon (when performing the send animation.)!
    // Will be automatically released, when the ComposeViewController is released.
    [self setIvar:@"GMDelegate" value:delegate];
}
@end
