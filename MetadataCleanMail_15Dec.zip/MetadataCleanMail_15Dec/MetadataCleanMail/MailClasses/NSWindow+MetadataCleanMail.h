//
//  NSWindow+MetadataCleanMail.h
//  MetadataCleanMail
//
//  Created by DATAPPS on 12/10/17.
//  Copyright © 2017 Test. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSWindow (MetadataCleanMail)

/**
 Allows to add an accessory view to a NSWindow which will be
 added to the top right.
 */
- (void)addAccessoryView:(NSView *)accessoryView;

/**
 Positions the accessory view at the top right of the theme frame.
 */
- (void)positionAccessoryView:(NSView *)accessoryView;

/**
 Positions the accessory view at the top right, but allows the set an offset.
 */
- (void)positionAccessoryView:(NSView *)accessoryView offset:(NSPoint)offset;

/**
 Centers an accessory view horizontally in the theme frame.
 */
- (void)centerAccessoryView:(NSView *)accessoryView;

/**
 Is called by Mail.app whenever the user clicks the fullscreen toggle button.
 This method is injected for immediately hiding any accessory views in any document
 editors, so there's no glitch in the fullscreen to normal window animation.
 */
- (void)MCM_ToggleFullScreen:(id)sender;

//- (id)titlebarView;
@end
