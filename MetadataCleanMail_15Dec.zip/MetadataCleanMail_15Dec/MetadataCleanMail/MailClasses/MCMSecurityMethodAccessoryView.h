//
//  MCMSecurityMethodAccessoryView.h
//  MetadataCleanMail
//
//  Created by DATAPPS on 12/10/17.
//  Copyright © 2017 Test. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Cocoa/Cocoa.h>
#define GMSMA_DEFAULT_HEIGHT 25.0f
#define GMSMA_DEFAULT_WIDTH 120.0f
#define GMSMA_FULLSCREEN_HEIGHT 22.0f


typedef NS_ENUM(NSInteger, MCMSecurityMethodAccessoryViewStyle) {
    MCMSecurityMethodAccessoryViewStyleToolbarItem,
    MCMSecurityMethodAccessoryViewStyleWindowAccessory
};


@interface MCMSecurityMethodAccessoryView : NSButton {
    BOOL _active;
    MCMSecurityMethodAccessoryViewStyle _style;
}
@property (nonatomic, assign) BOOL active;
@property (nonatomic, assign) MCMSecurityMethodAccessoryViewStyle style;

- (id)init;
- (id)initWithStyle:(MCMSecurityMethodAccessoryViewStyle)style;


@end
