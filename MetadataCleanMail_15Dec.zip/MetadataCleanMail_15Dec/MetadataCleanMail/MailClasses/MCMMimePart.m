//
//  MCMMimePart.m
//  MetadataCleanMail
//
//  Created by Nayome Devapriya on 15/12/17.
//  Copyright © 2017 Test. All rights reserved.
//

#import "MCMMimePart.h"
#import "MCAttachment.h"
#import "ParsedMessage.h"
#import "MCMProcessingAlert.h"

@implementation MCMMimePart

- (BOOL)MCM_usesKnownSignatureProtocol {
    NSLog(@"MCMUsesKnownSignatureProtocol");
    //return YES;
    return [self MCM_usesKnownSignatureProtocol];
}

- (id)MCM_decodeWithContext:(id)ctx {
    NSLog(@"MCM_decodeWithContext");
    
    id decryptedPart = nil;
    
    id nativePart = [self MCM_decodeWithContext:ctx];
    NSString *className = NSStringFromClass([nativePart class]);
    if ([className isEqualToString:@"MCParsedMessage"]) {
        NSLog(@"### all values is %@",[((ParsedMessage *)nativePart).attachmentsByURL allValues]);
        
        // Iterate throw all attachements and decrypt
        for (MCAttachment * attach in [((ParsedMessage *)nativePart).attachmentsByURL allValues]) {
            // TODO: Check for need to decrypt by attach.originalData
            NSLog(@"file name is %@",attach.filename);
            MCMProcessingAlert *alert = [[MCMProcessingAlert alloc] init];
            alert.fileName = attach.filename;
            [NSApp runModalForWindow:[alert window]];

//            NSData * decryptedAttach = [[VirgilProcessingManager sharedInstance]
//                                        decryptedAttachementByName:attach.filename];
//            if (nil != decryptedAttach) {
//                attach.currentData = decryptedAttach;
//            }
        }
        
        decryptedPart = nativePart;
        
    } else {
//        decryptedPart = [[VirgilProcessingManager sharedInstance]
//                         decryptMessagePart:(MimePart *)self];
    }
    
    return (nil != decryptedPart) ?
    decryptedPart :
    nativePart;
}

- (id)MCM_decodeTextPlainWithContext:(MFMimeDecodeContext *)ctx {
    NSLog(@"MCM_decodeTextPlainWithContext");
//    id decryptedPart =
//    [[VirgilProcessingManager sharedInstance] decryptMessagePart:(MimePart *)self];
//
//    return (nil != decryptedPart) ?
//    decryptedPart :
    return [self MCM_decodeTextPlainWithContext:ctx];
}

- (id)MCM_decodeTextHtmlWithContext:(MFMimeDecodeContext *)ctx {
//    NSLog(@"MCM_decodeTextHtmlWithContext");
//    id decryptedPart =
//    [[VirgilProcessingManager sharedInstance] decryptMessagePart:(MimePart *)self];
//
//    return (nil != decryptedPart) ?
//    decryptedPart :
    return [self MCM_decodeTextHtmlWithContext:ctx];
}

- (id)MCM_decodeApplicationOctet_streamWithContext:(MFMimeDecodeContext *)ctx {
    NSLog(@"MCM_decodeApplicationOctet_streamWithContext");
    return [self MCM_decodeApplicationOctet_streamWithContext:ctx];
}

- (void)MCM_verifySignature {
    NSLog(@"MCM_verifySignature");
    return [self MCM_verifySignature];
}

- (BOOL)MCM_isEncrypted {
    NSLog(@"MCM_isEncrypted");
    return [self MCM_isEncrypted];
}

- (BOOL)MCM_isMimeEncrypted {
    NSLog(@"MCM_isMimeEncrypted");
    return [self MCM_isMimeEncrypted];
}

- (BOOL)MCM_isSigned {
    NSLog(@"MCM_isSigned");
    return [self MCM_isSigned];
}

- (BOOL)MCM_IsMimeSigned {
    NSLog(@"MCMIsMimeSigned");
    return [self MCM_IsMimeSigned];
}

- (id)MCM_newEncryptedPartWithData:(NSData *)data recipients:(id)recipients encryptedData:(NSData **)encryptedData NS_RETURNS_RETAINED {
    NSLog(@"MCM_newEncryptedPartWithData");
    return [self MCM_newEncryptedPartWithData:data recipients:recipients encryptedData:encryptedData];
}

- (id)MCM_newSignedPartWithData:(id)data sender:(id)sender signatureData:(id *)signatureData NS_RETURNS_RETAINED {
    NSLog(@"MCM_newSignedPartWithData");
    return [self MCM_newSignedPartWithData:data sender:sender signatureData:signatureData];
}

- (void)MCM_clearCachedDecryptedMessageBody {
    NSLog(@"MCM_clearCachedDecryptedMessageBody");
    return [self MCM_clearCachedDecryptedMessageBody];
}
@end
