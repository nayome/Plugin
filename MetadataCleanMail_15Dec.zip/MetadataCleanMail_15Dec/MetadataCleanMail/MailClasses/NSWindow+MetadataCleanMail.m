//
//  NSWindow+MetadataCleanMail.m
//  MetadataCleanMail
//
//  Created by DATAPPS on 12/10/17.
//  Copyright © 2017 Test. All rights reserved.
//

#import "NSWindow+MetadataCleanMail.h"
#import "MCMMailDocumentEditor.h"

@implementation NSWindow (MetadataCleanMail)

- (void)addAccessoryView:(NSView *)accessoryView {
    NSView *themeFrame = [[self contentView] superview];
    [self positionAccessoryView:accessoryView];
    [themeFrame addSubview:accessoryView];
}

- (void)positionAccessoryView:(NSView *)accessoryView {
    [self positionAccessoryView:accessoryView offset:NSMakePoint(0.0f, 0.0f)];
}

- (void)positionAccessoryView:(NSView *)accessoryView offset:(NSPoint)offset {
    NSView *themeFrame = [[self contentView] superview];
    NSRect c = [themeFrame frame];    // c for "container"
    NSRect aV = [accessoryView frame];    // aV for "accessory view"
    
    NSRect newFrame = NSMakeRect(
                                 c.size.width - aV.size.width - offset.x,    // x position
                                 c.size.height - aV.size.height - offset.y,    // y position
                                 aV.size.width,    // width
                                 aV.size.height);    // height
    
    [accessoryView setFrame:newFrame];
}

- (void)centerAccessoryView:(NSView *)accessoryView {
    NSView *themeFrame = [[self contentView] superview];
    NSRect c = [themeFrame frame];    // c for "container"
    NSRect aV = [accessoryView frame];    // aV for "accessory view"
    aV.origin.x = floorf((c.size.width - aV.size.width) / 2.0f);
    
    [accessoryView setFrame:aV];
}

- (void)MCM_ToggleFullScreen:(id)sender {
    // Loop through all document editors and remove the security method
    // accessory view, so there's no animation glitch.
   NSLog(@"$$$$$$$ Toggle fullscreen: remove security method accessory view");
//    for(Mail *editor in [NSClassFromString(@"MailDocumentEditor") documentEditors]) {
//        if(editor.isModal)
//            [((MailDocumentEditor_GPGMail *)editor) hideSecurityMethodAccessoryView];
//    }
    [self MCM_ToggleFullScreen:sender];
}
@end
