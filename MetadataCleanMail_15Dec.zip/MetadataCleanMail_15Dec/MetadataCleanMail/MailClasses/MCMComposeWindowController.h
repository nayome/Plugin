//
//  MCMComposeWindowController.h
//  MetadataCleanMail
//
//  Created by DATAPPS on 12/10/17.
//  Copyright © 2017 Test. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MCMComposeWindowController : NSObject
- (void)restorePositionBeforeAnimation;
@end
