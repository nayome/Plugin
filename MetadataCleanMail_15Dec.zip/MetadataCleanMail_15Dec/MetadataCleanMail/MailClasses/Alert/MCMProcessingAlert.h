//
//  MCMProcessingAlert.h
//  MetadataCleanMail
//
//  Created by Nayome Devapriya on 12/12/17.
//  Copyright © 2017 Test. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MCMProcessingAlert : NSWindowController {
    
}
@property (nonatomic,strong) NSString* fileName;

@property (weak) IBOutlet NSProgressIndicator *fileProgressIndicator;
@property (weak) IBOutlet NSTextField *processingFileInfo;
@property (weak) IBOutlet NSProgressIndicator *progressIndicator;
- (IBAction)stop:(id)sender;
-(void) startProcessing:(NSArray *)attachments;
@end
