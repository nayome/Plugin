//
//  MCMProcessingAlert.m
//  MetadataCleanMail
//
//  Created by Nayome Devapriya on 12/12/17.
//  Copyright © 2017 Test. All rights reserved.
//

#import "MCMProcessingAlert.h"
#import "AttachmentViewController.h"
#import "MCAttachment.h"
@interface MCMProcessingAlert()
@property (nonatomic,strong) NSNumber* fileProgressValue;

@end

@implementation MCMProcessingAlert


- (void)windowDidLoad
{
    [super windowDidLoad];
    _fileProgressValue = [NSNumber numberWithInteger:0];
    self.fileProgressIndicator.doubleValue = _fileProgressValue.doubleValue;
    [self.progressIndicator startAnimation:nil];
    

}

-(void) startProcessing:(NSArray *)attachments {
    for (AttachmentViewController *attachVC in attachments) {
        NSLog(@" file name is %@",attachVC.attachment.filename);
        self.fileName = [NSString stringWithFormat:@"Processing ... %@", self.fileName];
    }
}

- (NSString *)windowNibName {
    return NSStringFromClass([MCMProcessingAlert class]);
}

- (void)awakeFromNib
{
    [[self window] center];
}

- (void)stopProcessing {
    [NSApp stopModal];
    [self close];
}
- (IBAction)stop:(id)sender {
    [NSApp stopModal];
    [self close];
}
@end
