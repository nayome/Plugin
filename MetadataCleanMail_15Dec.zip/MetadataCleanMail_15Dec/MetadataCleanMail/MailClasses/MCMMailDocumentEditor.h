//
//  MCMMailDocumentEditor.h
//  MetadataCleanMail
//
//  Created by DATAPPS on 12/10/17.
//  Copyright © 2017 Test. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MCMSecurityMethodAccessoryView.h"
#import "MCMMailMessage.h"


@interface MCMMailDocumentEditor : NSObject <NSMenuDelegate>


/**
 Inject to un-observe any notifications.
 */
- (void)MADealloc;

@property (nonatomic, retain) MCMSecurityMethodAccessoryView    *securityMethodAccessoryView;
- (void)updateSecurityMethodHighlight;

@end

@interface MCMMailDocumentEditor (NotImplemented)

- (id)delegate;
@end
