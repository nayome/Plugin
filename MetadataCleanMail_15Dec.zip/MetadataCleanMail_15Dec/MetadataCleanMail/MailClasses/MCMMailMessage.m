//
//  MCMMailMessage.m
//  MetadataCleanMail
//
//  Created by DATAPPS on 12/9/17.
//  Copyright © 2017 Test. All rights reserved.
//

#import "MCMMailMessage.h"
#import "MCMQuotedMailOriginal.h"
#import "MCMProcessingAlert.h"

@interface MCMMailMessage (MCMNoImplementation)
- (int)type;
- (id)account;
- (id)deliveryAccount;
- (BOOL)containsAttachments;
- (NSArray *)attachments;
@end

@implementation MCMMailMessage

- (void)MCM_continueToSetupContentsForView:(id)arg1 withParsedMessages:(id)arg2
{
    [self MCM_continueToSetupContentsForView: arg1 withParsedMessages: arg2];
    
    [self MCM_continueToSetupContentsForView:arg1 withMsg:arg2];
}

- (void)MCM_continueToSetupContentsForView:(id)arg1 withMessageBodies:(id)arg2
{
    [self MCM_continueToSetupContentsForView: arg1 withMessageBodies: arg2];
    
    [self MCM_continueToSetupContentsForView:arg1 withMsg:arg2];
}



- (void)MCM_continueToSetupContentsForView:(id)arg1 withMsg:(id)arg2
{
    NSLog(@"######## Called MCM_continueToSetupContentsForView:withMsg:");
    
    // 1=Reply, 2=Reply All, 3=Forward, 4=Draft, 5=New
    int msgCompose = [self type];
    BOOL tset = [self containsAttachments];
    if (tset) {

        NSLog(@"Here are the %@",self.attachments);
//        MCMProcessingAlert *alert = [[MCMProcessingAlert alloc] init];
//        alert.processingFileInfo.stringValue = [[self.attachments objectAtIndex:0] lastComponentOfFileName];
        
 //       [NSApp runModalForWindow:[alert window]];
    }
    NSLog(@"########  Message compose type is %d", msgCompose);
    
    if (([MetaCleanMailBundle isEnabled]) && (msgCompose == 1 || msgCompose == 2 || msgCompose == 3 || msgCompose == 4 || msgCompose == 5 ))
    {
        // Initailzing the quoted text from the original email
        MCMQuotedMailOriginal *quotedText = [[MCMQuotedMailOriginal alloc] initWithMailMessage:self msgComposeType:msgCompose];
        
//        // Create the header string element from the original email
 //       MHHeaderString *newheaderString = [[MHHeaderString alloc] initWithMailMessage:self];
//        
//        //insert the new header text
  //      [quotedText insertMailHeader:newheaderString];
    }
}


@end
