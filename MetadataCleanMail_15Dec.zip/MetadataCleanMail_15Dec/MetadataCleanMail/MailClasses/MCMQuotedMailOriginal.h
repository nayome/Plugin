//
//  MCMQuotedMailOriginal.h
//  MetadataCleanMail
//
//  Created by DATAPPS on 12/9/17.
//  Copyright © 2017 Test. All rights reserved.
//

#import <Foundation/Foundation.h>
@class  DOMDocumentFragment, DOMHTMLDivElement, DOMNodeList;

@interface MCMQuotedMailOriginal : NSObject {
@private
    id document;
    DOMDocumentFragment *headerBorder;
    BOOL isHTMLMail;
    DOMHTMLDivElement *originalEmail;
    int textNodeLocation; //which
    DOMNodeList *dhc; //document header children
    int msgComposeType;
}

- (id)initWithMailMessage:(id)mailMessage msgComposeType:(int)composeType;

@end
