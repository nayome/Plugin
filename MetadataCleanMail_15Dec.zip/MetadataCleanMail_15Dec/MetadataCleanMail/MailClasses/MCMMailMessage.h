//
//  MCMMailMessage.h
//  MetadataCleanMail
//
//  Created by DATAPPS on 12/9/17.
//  Copyright © 2017 Test. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MCMMailMessage : NSObject
- (void)MCM_continueToSetupContentsForView:(id)arg1 withParsedMessages:(id)arg2;
@end
