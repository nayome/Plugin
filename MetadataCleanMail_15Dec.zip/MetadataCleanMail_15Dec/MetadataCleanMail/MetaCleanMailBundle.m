//
//  MetaCleanMailBundle.m
//  MetadataCleanMail
//
//  Created by Nayome on 12/9/17.
//  Copyright © 2017 Test. All rights reserved.
//

#import "MetaCleanMailBundle.h"
#import "MCMCodeInjector.h"
#import "MCMComposeViewController.h"

@interface MetaCleanMailBundle (MCMNoImplementation)
+ (void)registerBundle;
@end

@implementation MetaCleanMailBundle

+ (BOOL)isEnabled
{
    return [[NSUserDefaults standardUserDefaults] boolForKey:@"MCMBundleEnabled"];
    //GET_DEFAULT_BOOL(MHBundleEnabled);
}

+ (NSString *)osxVersionString
{
    return [[NSProcessInfo processInfo] operatingSystemVersionString];
}

+ (NSBundle *)bundle
{
    static NSBundle *bundle;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        bundle = [NSBundle bundleForClass:[MetaCleanMailBundle class]];
    });
    return bundle;
}

+ (NSString *)bundleNameAndVersion
{
    return [NSMutableString stringWithFormat:@"%@ v%@", [self bundleName], [self bundleVersionString]];
}

+ (NSString *)bundleName
{
    return @"MetadataCleanMail";
}

+ (NSString *)bundleVersionString
{
    return [[[self bundle] infoDictionary] objectForKey:MCMBundleShortVersionKey];
}

+ (void)assignUserDefaults
{
    NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:
                          [NSNumber numberWithBool:YES], @"MCMBundleEnabled",
                          nil
                          ];
    // set defaults
    [[NSUserDefaults standardUserDefaults] registerDefaults:dict];
}

+ (BOOL)isHighSierraOrGreater // 10.13.x or greater
{
    return floor(NSAppKitVersionNumber) >= 1561;
}

+ (Class)resolveMailClassFromName:(NSString *)name {
    NSArray *prefixes = @[@"", @"MC", @"MF"];
    
    // MessageWriter is called MessageGenerator under Mavericks.
    if([name isEqualToString:@"MessageWriter"] && !NSClassFromString(@"MessageWriter"))
        name = @"MessageGenerator";
    
    __block Class resolvedClass = nil;
    [prefixes enumerateObjectsUsingBlock:^(NSString *prefix, NSUInteger idx, BOOL *stop) {
        NSString *modifiedName = [name copy];
        if([prefixes containsObject:[modifiedName substringToIndex:2]])
            modifiedName = [modifiedName substringFromIndex:2];
        
        NSString *className = [prefix stringByAppendingString:modifiedName];
        resolvedClass = NSClassFromString(className);
        if(resolvedClass)
            *stop = YES;
    }];
    
    return resolvedClass;
}



#pragma mark MVMailBundle initialize

+ (void)initialize
{
    NSLog(@"##########  Initialising...");

    // Make sure the initializer is only run once.
    // Usually is run, for every class inheriting from MailHeader.
    if (self != [MetaCleanMailBundle class])
        return;
    
    Class mvMailBundleClass = NSClassFromString(@"MVMailBundle");
    // If this class is not available that means Mail.app
    // doesn't allow bundles anymore. Fingers crossed that this never happens!
    if (!mvMailBundleClass) {
        NSLog(@"MCM Mail.app doesn't support bundles anymore, so have a beer and relax !");
        
        return;
    }
    
    // Registering plugin in Mail.app
    [mvMailBundleClass registerBundle];
    
    NSLog(@"##########  MCM Bundle registered succesfully...");

    // Assigning default value if not present
    [self assignUserDefaults];
    NSLog(@"##########  Assigning user defauts...");

    // Add hooks into Mail.app Classes
    [MCMCodeInjector injectMailHeaderCode];

    // Bundle registered successfully
    NSLog(@"RWH %@ plugin loaded, OS X %@", [self bundleNameAndVersion], [self osxVersionString]);
//
//    // Logger
//    BOOL logEnabled = GET_DEFAULT_BOOL(MHLogEnabled);
//    [MLog setLogOn:logEnabled];
//    NSLog(@"RWH %@ debug log enabled: %@", [self bundleNameAndVersion], logEnabled ? @"YES" : @"NO");
//
//    // fix for #26 https://github.com/jeevatkm/ReplyWithHeader/issues/26
//    if ( ![self isLocaleSupported] )
//    {
//        NSLocale *locale = [[NSLocale alloc] initWithLocaleIdentifier:[self localeIdentifier]];
//        NSString *name = [locale displayNameForKey:NSLocaleIdentifier value:[self localeIdentifier]];
//
//        NSString *msgStr = [NSString stringWithFormat:@"%@ is currently not supported in your Locale[ %@(%@) ] it may not work as expected, so disabling it.\nPlease contact plugin author - https://github.com/jeevatkm/ReplyWithHeader/issues.", [self bundleNameAndVersion], name, [self localeIdentifier]];
//
//        NSLog(@"RWH WARNING :: %@", msgStr);
//
//        SET_DEFAULT_BOOL(FALSE, MHBundleEnabled);
//
//        NSAlert *warnAlert = [[NSAlert alloc] init];
//        [warnAlert setAlertStyle:NSWarningAlertStyle];
//        [warnAlert setMessageText:[NSMutableString stringWithFormat:@"Warning: %@", [MailHeader bundleNameAndVersion]]];
//        [warnAlert setInformativeText:msgStr];
//        [warnAlert setIcon:[MailHeader bundleLogo]];
//        [warnAlert runModal];
//    }
//
//    if (![self isEnabled])
//    {
//        NSLog(@"RWH %@ plugin is disabled in mail preferences", [self bundleName]);
//    }
//
//    if (GET_DEFAULT_BOOL(MHPluginNotifyNewVersion))
//    {
//        double delayInSeconds = 30.0;
//        dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
//        dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
//            MHUpdater *updater = [[MHUpdater alloc] init];
//            if ([updater isUpdateAvailable])
//                [updater showUpdateAlert];
//        });
//    }
}
@end
