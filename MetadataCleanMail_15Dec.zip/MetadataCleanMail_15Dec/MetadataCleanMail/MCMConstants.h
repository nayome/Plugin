//
//  MCMConstants.h
//  MetadataCleanMail
//
//  Created by Nayome on 12/9/17.
//  Copyright © 2017 Test. All rights reserved.
//

#ifndef MCMConstants_h
#define MCMConstants_h

#define MCMBundleNameKey @"CFBundleName"
#define MCMBundleVersionKey @"CFBundleVersion"
#define MCMBundleShortVersionKey @"CFBundleShortVersionString"
#define MCMBundleIdentifier @"CFBundleIdentifier"
#define MCMCopyRightKey @"NSHumanReadableCopyright"

#endif /* MCMConstants_h */
