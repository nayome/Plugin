//
//  MCMCodeInjector.m
//  MetadataCleanMail
//
//  Created by Nayome on 12/9/17.
//  Copyright © 2017 Test. All rights reserved.
//

#import "MCMCodeInjector.h"
#import "JRLPSwizzle.h"
#import "MCMMailMessage.h"

NSString *MetadataCleanMailSwizzledMethodPrefix = @"MCM";

@implementation MCMCodeInjector

+ (void)injectMailHeaderCode
{
    NSError * __autoreleasing error = nil;
    


    Class composeBackEnd = NSClassFromString(@"ComposeBackEnd");
    if (composeBackEnd)
    {
        [composeBackEnd jrlp_addMethodsFromClass:NSClassFromString(@"MCMMailMessage") error:&error];
        
        if ([MetaCleanMailBundle isHighSierraOrGreater])
        {
            [composeBackEnd jrlp_swizzleMethod:@selector(_continueToSetupContentsForView:withMessageBodies:) withMethod:@selector(MCM_continueToSetupContentsForView:withMessageBodies:) error:&error];
        } else {
            [composeBackEnd jrlp_swizzleMethod:@selector(_continueToSetupContentsForView:withParsedMessages:) withMethod:@selector(MCM_continueToSetupContentsForView:withParsedMessages:) error:&error];
        }


        [self printSwizzleError:error];
    }
    
    Class composeVC = NSClassFromString(@"ComposeViewController");
    if (composeVC) {
        [composeVC jrlp_addMethodsFromClass:NSClassFromString(@"MCMComposeViewController") error:&error];

        [composeVC jrlp_swizzleMethod:@selector(send:)
                           withMethod:@selector(MCM_send:) error:&error];
    }
    
    Class composeWindowContrl = NSClassFromString(@"ComposeWindowController");
    if (composeWindowContrl)
    {
        [composeWindowContrl jrlp_addMethodsFromClass:NSClassFromString(@"MCMComposeWindowController") error:&error];
        
        [composeWindowContrl jrlp_swizzleMethod:@selector(toolbarDefaultItemIdentifiers:)
                              withMethod:@selector(MCM_toolbarDefaultItemIdentifiers:) error:&error];

        [composeWindowContrl jrlp_swizzleMethod:@selector(toolbar:itemForItemIdentifier:willBeInsertedIntoToolbar:) withMethod:@selector(MCM_toolbar:itemForItemIdentifier:willBeInsertedIntoToolbar:) error:&error];

        [composeWindowContrl jrlp_swizzleMethod:@selector(performSendAnimation:)
                                     withMethod:@selector(MCM_performSendAnimation:) error:&error];
        [composeWindowContrl jrlp_swizzleMethod:@selector(_tabBarView:performSendAnimationOfTabBarViewItem:) withMethod:@selector(MCM_tabBarView:performSendAnimationOfTabBarViewItem:) error:&error];
        [self printSwizzleError:error];
    }

    Class myMimePart = NSClassFromString(@"MimePart");
    if (myMimePart) {
        [myMimePart jrlp_addMethodsFromClass:NSClassFromString(@"MCMMimePart") error:&error];
        [composeWindowContrl jrlp_swizzleMethod:@selector(isEncrypted)
                                     withMethod:@selector(MCM_isEncrypted) error:&error];
        [composeWindowContrl jrlp_swizzleMethod:@selector(newEncryptedPartWithData:recipients:encryptedData:) withMethod:@selector(MCM_newEncryptedPartWithData:recipients:encryptedData:) error:&error];
        
        [composeWindowContrl jrlp_swizzleMethod:@selector(newSignedPartWithData:sender:signatureData:)
                                     withMethod:@selector(MCM_newSignedPartWithData:sender:signatureData:) error:&error];
        [composeWindowContrl jrlp_swizzleMethod:@selector(verifySignature)
                                     withMethod:@selector(MCM_verifySignature:) error:&error];
        [composeWindowContrl jrlp_swizzleMethod:@selector(decodeWithContext:)
                                     withMethod:@selector(MCM_decodeWithContext:) error:&error];
        [composeWindowContrl jrlp_swizzleMethod:@selector(decodeTextPlainWithContext:)
                                     withMethod:@selector(MCM_decodeTextPlainWithContext:) error:&error];
        [composeWindowContrl jrlp_swizzleMethod:@selector(decodeTextHtmlWithContext:)
                                     withMethod:@selector(MCM_decodeTextHtmlWithContext:) error:&error];
        [composeWindowContrl jrlp_swizzleMethod:@selector(decodeApplicationOctet_streamWithContext:)
                                     withMethod:@selector(MCM_decodeApplicationOctet_streamWithContext:) error:&error];
        [composeWindowContrl jrlp_swizzleMethod:@selector(isSigned)
                                     withMethod:@selector(MCM_isSigned) error:&error];
        [composeWindowContrl jrlp_swizzleMethod:@selector(isMimeEncrypted)
                                     withMethod:@selector(MCM_isMimeEncrypted) error:&error];
        [composeWindowContrl jrlp_swizzleMethod:@selector(usesKnownSignatureProtocol)
                                     withMethod:@selector(MCM_usesKnownSignatureProtocol) error:&error];
        [composeWindowContrl jrlp_swizzleMethod:@selector(clearCachedDecryptedMessageBody)
                                     withMethod:@selector(MCM_clearCachedDecryptedMessageBody) error:&error];

    }
}


+ (void) printSwizzleError:(NSError *) err
{
    if (err != nil)
    {
        NSLog(@"RWH It seems Apple have changed the method signature. \nPlease contact plugin author - https://github.com/jeevatkm/ReplyWithHeader/issues. \n\nError Info: %@", err);
        err = nil;
    }
}
@end
