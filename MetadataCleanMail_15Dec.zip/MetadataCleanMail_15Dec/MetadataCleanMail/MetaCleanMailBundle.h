//
//  MetaCleanMailBundle.h
//  MetadataCleanMail
//
//  Created by Nayome on 12/9/17.
//  Copyright © 2017 Test. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MetaCleanMailBundle : NSObject
+ (BOOL)isEnabled;
+ (NSBundle *)bundle;
+ (NSString *)bundleNameAndVersion;
+ (NSString *)bundleName;
+ (NSString *)bundleVersionString;
+ (BOOL)isHighSierraOrGreater;
+ (NSString *)osxVersionString;
@end
