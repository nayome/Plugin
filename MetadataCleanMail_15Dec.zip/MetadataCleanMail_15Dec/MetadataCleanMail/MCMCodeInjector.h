//
//  MCMCodeInjector.h
//  MetadataCleanMail
//
//  Created by Nayome on 12/9/17.
//  Copyright © 2017 Test. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MCMCodeInjector : NSObject
+ (void)injectMailHeaderCode;
@end
