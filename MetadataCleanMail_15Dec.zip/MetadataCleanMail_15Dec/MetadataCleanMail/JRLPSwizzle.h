//
//  JRLPSwizzle.h
//  MetadataCleanMail
//
//  Created by Nayome on 12/9/17.
//  Copyright © 2017 Test. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSObject (JRLPMCMSwizzle)

+ (BOOL)jrlp_swizzleMethod:(SEL)origSel_ withMethod:(SEL)altSel_ error:(NSError**)error_;
+ (BOOL)jrlp_swizzleClassMethod:(SEL)origSel_ withClassMethod:(SEL)altSel_ error:(NSError**)error_;
+ (BOOL)jrlp_addClassMethod:(SEL)selector fromClass:(Class)class error:(NSError **)error;
+ (BOOL)jrlp_addMethod:(SEL)selector fromClass:(Class)class error:(NSError **)error;
+ (BOOL)jrlp_addMethodsFromClass:(Class)aClass error:(NSError **)error;

@end

